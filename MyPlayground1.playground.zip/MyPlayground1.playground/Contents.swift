import UIKit

var str = "Hello"
// var to declare variables
str = "Hello , how are you"
// you can change the value of variables

let constantString = "Hey"

// let use to declare constants
//constantString = "Hey , Hello " (You can do this bcz constants are not change



print (str)

print (constantString)



